<?php
include('db.php'); // Database connection

$id = $_GET['id'];
$query = "DELETE FROM users WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
?>
