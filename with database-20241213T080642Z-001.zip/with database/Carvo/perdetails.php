<?php
session_start(); // Start the session to access reservation data
include('db.php'); // Include your database connection file

// Check if reservation details are in the session
if (isset($_SESSION['reservation'])) {
    $reservation = $_SESSION['reservation'];
    $carId = $reservation['carId'];

    // Fetch the car details from the 'cars' table based on carId
    $sql = "SELECT name, category, seats, luggage, transmission, fuel_type, price_per_day FROM cars WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $carId);
        $stmt->execute();
        $stmt->bind_result($carName, $category, $seats, $luggage, $transmission, $fuelType, $pricePerDay);
        $stmt->fetch();
        $stmt->close();

        // Check if the car was found
        if (!$carName || !$category || !$seats || !$luggage || !$transmission || !$fuelType) {
            $carName = 'Unknown Car'; // Default in case of an error
            $category = 'Unknown Category';
            $seats = 'Unknown';
            $luggage = 'Unknown';
            $transmission = 'Unknown';
            $fuelType = 'Unknown';
            $pricePerDay = 0; // Default price
        }
    } else {
        $carName = 'Unknown Car'; // Default in case of an error
        $category = 'Unknown Category';
        $seats = 'Unknown';
        $luggage = 'Unknown';
        $transmission = 'Unknown';
        $fuelType = 'Unknown';
        $pricePerDay = 0; // Default price
    }

    // Calculate rental duration (assuming pickup and return dates are in 'Y-m-d' format)
    $pickupDate = new DateTime($reservation['pickupDate']);
    $returnDate = new DateTime($reservation['returnDate']);
    $duration = $pickupDate->diff($returnDate)->days;

    // Ensure that the duration is at least 1 day
    if ($duration < 1) {
        $duration = 1; // Set to 1 day if it's less than 1
    }

    $rentalFee = $duration * $pricePerDay;

    // Customer details
    $name = htmlspecialchars($reservation['name']);
    $email = htmlspecialchars($reservation['email']);
    $phone = htmlspecialchars($reservation['phone']);
    $pickupLocation = htmlspecialchars($reservation['pickupLocation']);
    $returnLocation = htmlspecialchars($reservation['returnLocation']);
    $sameLocation = $reservation['sameLocation'] ? 'Yes' : 'No';
} else {
    // Redirect to the home page if no reservation found
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservation Details</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="p-3">
            <nav class="navbar navbar-expand-lg fixed-top fleet-navbar">
                <a class="navbar-brand" href="#">
                    <img src="logo.png" alt="Logo" height="30">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a href="index.html" class="nav-link">HOME</a></li>
                        <li class="nav-item"><a href="fleet.html" class="nav-link active" aria-current="page">FLEET</a></li>
                        <li class="nav-item"><a href="about-us.html" class="nav-link">ABOUT US</a></li>
                        <li class="nav-item"><a href="contact.html" class="nav-link">CONTACT US</a></li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="hero-section-fleet">
        <div class="overlay-fleet"></div>
        <div class="container text-center text-white">
            <h1>OUR FLEET</h1>
            <p>Find the perfect ride in our collection of clean, quality-assured vehicles.</p>
        </div>
    </div>
    <div class="container mt-5">
        <h1>Reservation Confirmation</h1>
        <p>Thank you for your reservation. Here are the details:</p>

        <form action="payment.php" method="POST">
            <!-- Reservation Details Table -->
            <table class="table table-bordered">
                <tr>
                    <th>Reservation ID</th>
                    <td><?php echo $reservation['reservationId']; ?></td>
                </tr>
                <tr>
                    <th>Car</th>
                    <td><?php echo htmlspecialchars($carName); ?></td> <!-- Display the car name here -->
                </tr>
                <tr>
                    <th>Pick-up Date/Time</th>
                    <td><?php echo $reservation['pickupDate'] . ' ' . $reservation['pickupTime']; ?></td>
                </tr>
                <tr>
                    <th>Return Date/Time</th>
                    <td><?php echo $reservation['returnDate'] . ' ' . $reservation['returnTime']; ?></td>
                </tr>
                <tr>
                    <th>Pick-up Location</th>
                    <td><?php echo $reservation['pickupLocation']; ?></td>
                </tr>
                <tr>
                    <th>Return Location</th>
                    <td><?php echo $reservation['returnLocation']; ?></td>
                </tr>
                <tr>
                    <th>Same Location for Return?</th>
                    <td><?php echo $reservation['sameLocation'] ? 'Yes' : 'No'; ?></td>
                </tr>
            </table>

            <h3>Edit Personal Information</h3>
            <!-- Editable Fields -->
            <table class="table table-bordered">
                <tr>
                    <th>Name</th>
                    <td><input type="text" name="name" value="<?php echo htmlspecialchars($reservation['name']); ?>" required></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><input type="email" name="email" value="<?php echo htmlspecialchars($reservation['email']); ?>" required></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><input type="tel" name="phone" value="<?php echo htmlspecialchars($reservation['phone']); ?>" required></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td><input type="text" name="address" ?></td>
                </tr>
                <tr>
                    <th>City</th>
                    <td><input type="text" name="city" ?></td>
                </tr>
            </table>

            <!-- Payment Method Section -->
            <h3>Select Payment Method</h3>
            <table class="table table-bordered">
                <tr>
                    <th>Payment Method</th>
                    <td>
                        <select name="payment-method" required>
                            <option value="">-- Select Payment Method --</option>
                            <option value="credit-card" >Credit Card</option>
                            <option value="paypal" >PayPal</option>
                            <option value="bank-transfer">Bank Transfer</option>
                        </select>
                    </td>
                </tr>
            </table>

            <!-- Submit Changes -->
            <button type="submit" class="btn btn-primary">Update Reservation</button>
        </form>

        <a href="index.html" class="btn btn-secondary mt-3">Back to Home</a>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const header = document.querySelector('header'); // Select the header element directly

            // Scroll event listener for the sticky header
            window.addEventListener('scroll', function() {
                if (window.scrollY > 50) {
                    header.classList.add('sticky');
                } else {
                    header.classList.remove('sticky');
                }
            });
        });
        </script>

    <!-- Include Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
