<?php
// Database connection
function dbConnect() {
    $host = 'localhost'; // Change as needed
    $dbname = 'carvo'; // Change to your database name
    $username = 'root'; // Change to your MySQL username
    $password = ''; // Change to your MySQL password

    try {
        return new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

// Fetch all users
function getAllUsers() {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("SELECT id, name, email, username, role FROM users");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Add a new user
function addUser($name, $email, $username, $password, $role) {
    $pdo = dbConnect();

    $stmt = $pdo->prepare("INSERT INTO users (name, email, username, password, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $email, $username, $password, $role]);
}

// Update an existing user
function updateUser($id, $name, $email, $username, $password, $role) {
    $pdo = dbConnect();

    if (!empty($password)) {
        // If a new password is provided, update it as well
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, username = ?, password = ?, role = ? WHERE id = ?");
        $stmt->execute([$name, $email, $username, $hashedPassword, $role, $id]);
    } else {
        // If no new password is provided, leave it unchanged
        $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, username = ?, role = ? WHERE id = ?");
        $stmt->execute([$name, $email, $username, $role, $id]);
    }
}

// Delete a user
function deleteUser($id) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
}
