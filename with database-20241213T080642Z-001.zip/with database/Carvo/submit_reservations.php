<?php
// Database connection
$host = 'localhost';
$dbname = 'carvo';
$username = 'root'; // your db username
$password = ''; // your db password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $pickupDate = $_POST['pickupDate'];
    $pickupTime = $_POST['pickupTime'];
    $returnDate = $_POST['returnDate'];
    $returnTime = $_POST['returnTime'];
    $pickupLocation = $_POST['pickupLocation'];
    $returnLocation = $_POST['returnLocation'];

    // Prepare SQL query to insert data
    $sql = "INSERT INTO reservations (name, email, phone, pickup_date, pickup_time, return_date, return_time, pickup_location, return_location) 
            VALUES (:name, :email, :phone, :pickupDate, :pickupTime, :returnDate, :returnTime, :pickupLocation, :returnLocation)";
    
    // Prepare statement
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':pickupDate', $pickupDate);
    $stmt->bindParam(':pickupTime', $pickupTime);
    $stmt->bindParam(':returnDate', $returnDate);
    $stmt->bindParam(':returnTime', $returnTime);
    $stmt->bindParam(':pickupLocation', $pickupLocation);
    $stmt->bindParam(':returnLocation', $returnLocation);

    // Execute query
    if ($stmt->execute()) {
        echo "Reservation successfully saved!";
    } else {
        echo "There was an error saving your reservation.";
    }
}
?>
