<?php
session_start();

// Include the database connection
include('db.php');  // Ensure the correct path to db.php is used

// Handle the login process
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted username and password
    $uname = $_POST['uname'];
    $psw = $_POST['psw'];

    // Check if the username and password are not empty
    if (!empty($uname) && !empty($psw)) {
        // Prepare the SQL query to select the user by username
        $query = "SELECT * FROM users WHERE username = ?";
        
        if ($stmt = $conn->prepare($query)) {
            // Bind the parameter to the prepared statement
            $stmt->bind_param('s', $uname);

            // Execute the statement
            $stmt->execute();
            
            // Get the result
            $result = $stmt->get_result();

            // Fetch the user data (returns false if no match)
            $user = $result->fetch_assoc();

            // Check if the user exists and verify the password (plain text comparison)
            if ($user && $psw === $user['password']) {
                // Store the user details in session
                $_SESSION['username'] = $uname; // Store username in session
                $_SESSION['name'] = $user['name']; // Store user's name in session
                $_SESSION['email'] = $user['email']; // Store user's email in session
                $_SESSION['phone'] = $user['phone']; // Store user's phone number in session

                // Check if the user is an admin
                if ($user['role'] === 'admin') {
                    $_SESSION['role'] = 'admin'; // Store the role in session if user is admin
                    header("Location: dashboard.html"); // Redirect to admin dashboard
                } else {
                    header("Location: index.html"); // Redirect to regular dashboard
                }
                exit();
            } else {
                $login_error = "Invalid username or password!";
            }

            // Close the prepared statement
            $stmt->close();
        } else {
            $login_error = "Error: " . $conn->error;
        }
    } else {
        $login_error = "Please fill in both username and password!";
    }
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        
        body {
            font-family: Arial, Helvetica, sans-serif;
            overflow: hidden;
        }

        h1 {
            font-size: 2.5rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
            color: #ffffff;
        }

        .hero-section-login {
            position: relative;
            width: 100%;
            height: 100vh;
            background-image: url('loginbg.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .hero-section-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }

        .container {
            z-index: 2;
        }

        .modal-content p, .modal-content .psw {
            font-size: 1rem;
            color: #000000;
            margin: 5px 0;
        }

        .modal-content a {
            color: #007bff;
            text-decoration: none;
        }

        .modal-content a:hover {
            text-decoration: underline;
        }

        input[type=text], input[type=password], input[type=email] {
            width: 100%;
            padding: 12px 15px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type=email]:focus {
            border-color: #007bff;
            outline: none;
        }

        button {
            background-color: red;
            color: white;
            padding: 12px;
            margin-top: 10px;
            border: none;
            cursor: pointer;
        }

        button.modal-btn {
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
        }

        .modal-dialog {
            margin-top: 10px;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1050;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 400px;
            margin: auto;
        }

        .close {
            position: absolute;
            right: 10px;
            top: 10px;
            width: 30px;
            height: 30px;
            color: #000;
            font-size: 30px;
            border-radius: 50%;
            background: #f1f1f1;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close:hover {
            color: red;
        }

        .log-in-footer {
            background-color: #323942;
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 10%;
            font-size: 0.9rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }

        .log-in-footer-copyright {
            color: #666;
        }

    </style>
    <title>Login</title>
</head>
<body>

    <div class="hero-section-login text-center text-white">
        <div class="overlay"></div>
        <div class="container">
            <img src="red logo.png" height="100" alt="Logo">
            <h1>DRIVE YOUR DREAMS</h1>
            <button class="btn btn-book-now" onclick="document.getElementById('id01').style.display='block'">LOG IN</button>
        </div>
    </div>

    <!-- Login Modal -->
    <div id="id01" class="modal" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form class="modal-content animate" action="login.php" method="POST">
                <div class="container">
                    <label for="uname"><b>Username</b></label>
                    <input type="text" placeholder="Enter Username" name="uname" required>

                    <label for="psw"><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="psw" required>

                    <button type="submit" class="modal-btn">Login</button>
                    <?php if (isset($login_error)) { echo "<p class='text-danger'>$login_error</p>"; } ?>
                    <label>
                        <input type="checkbox" name="remember"> Remember me
                    </label>
                </div>

                <div class="container text-center">
                    <span class="psw"><a href="#">Forgot password?</a></span><br>
                    <p>Don't have an account? <a href="#" onclick="toggleModal('signupModal', 'id01')">Sign up</a></p>
                </div>
            </form>
        </div>
    </div>

    <!-- Signup Modal -->
    <div id="signupModal" class="modal" role="dialog" aria-labelledby="signupModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form class="modal-content animate" action="signup_action.php" method="POST">
                <div class="container">
                    <label for="name"><b>Name</b></label>
                    <input type="text" placeholder="Enter Your Name" name="name" required>

                    <label for="email"><b>Email</b></label>
                    <input type="email" placeholder="Enter Email" name="email" required>

                    <label for="uname"><b>Username</b></label>
                    <input type="text" placeholder="Enter Username" name="uname" required>

                    <label for="psw"><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="psw" required>

                    <button type="submit" class="modal-btn">Sign Up</button>
                </div>
            </form>
        </div>
    </div>

    <footer class="log-in-footer text-white">
        <div class="container">
            <div class="log-in-footer-copyright text-center">© 2024 Copyright Carvo.com</div>
        </div>
    </footer>

    <script type="text/javascript">
        function toggleModal(showModalId, hideModalId = null) {
            if (hideModalId) {
                const hideModal = document.getElementById(hideModalId);
                if (hideModal) hideModal.style.display = "none";
            }
            const showModal = document.getElementById(showModalId);
            if (showModal) showModal.style.display = "block";
        }

        window.onclick = function(event) {
            const modals = [document.getElementById('id01'), document.getElementById('signupModal')];
            modals.forEach(modal => {
                if (modal && event.target === modal) {
                    modal.style.display = "none";
                }
            });
        };
    </script>

</body>
</html>
