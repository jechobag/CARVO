<?php
session_start(); // Start the session to access reservation data
include('db.php'); // Include your database connection file

// Check if reservation details are in the session
if (isset($_SESSION['reservation'])) {
    $reservation = $_SESSION['reservation'];
    $carId = $reservation['carId'];

    // Fetch the car details from the 'cars' table based on carId
    $sql = "SELECT name, category, seats, luggage, transmission, fuel_type, price_per_day FROM cars WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $carId);
        $stmt->execute();
        $stmt->bind_result($carName, $category, $seats, $luggage, $transmission, $fuelType, $pricePerDay);
        $stmt->fetch();
        $stmt->close();

        // Check if the car was found
        if (!$carName || !$category || !$seats || !$luggage || !$transmission || !$fuelType) {
            $carName = 'Unknown Car'; // Default in case of an error
            $category = 'Unknown Category';
            $seats = 'Unknown';
            $luggage = 'Unknown';
            $transmission = 'Unknown';
            $fuelType = 'Unknown';
            $pricePerDay = 0; // Default price
        }
    } else {
        $carName = 'Unknown Car'; // Default in case of an error
        $category = 'Unknown Category';
        $seats = 'Unknown';
        $luggage = 'Unknown';
        $transmission = 'Unknown';
        $fuelType = 'Unknown';
        $pricePerDay = 0; // Default price
    }

    // Calculate rental duration (assuming pickup and return dates are in 'Y-m-d' format)
    $pickupDate = new DateTime($reservation['pickupDate']);
    $returnDate = new DateTime($reservation['returnDate']);
    $duration = $pickupDate->diff($returnDate)->days;

    // Ensure that the duration is at least 1 day
    if ($duration < 1) {
        $duration = 1; // Set to 1 day if it's less than 1
    }

    $rentalFee = $duration * $pricePerDay;
} else {
    // Redirect to the home page or show an error if no reservation was found
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <title>Payment</title>
</head>
<body>
    <header class="p-3">
        <nav class="navbar navbar-expand-lg fixed-top">
            <a class="navbar-brand" href="#">
                <img src="logo.png" alt="Logo" height="30">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="index.html" class="nav-link">HOME</a></li>
                    <li class="nav-item"><a href="fleet.html" class="nav-link active" aria-current="page">FLEET</a></li>
                    <li class="nav-item"><a href="about us.html" class="nav-link">ABOUT US</a></li>
                    <li class="nav-item"><a href="contact.html" class="nav-link">CONTACT US</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="hero-section-fleet">
        <div class="overlay-fleet"></div>
        <div class="container text-center text-white">
            <h1>OUR FLEET</h1>
            <p>Find the perfect ride in our collection of clean, quality-assured vehicles.</p>
        </div>
    </div>

    <div class="container my-5">
        <p>Your reservation has been saved. Redirecting to payment gateway....</p>

        <form action="receipt.php" method="POST" id="bookingForm">
    <!-- Booking Details Table -->
    <div class="row">
        <div class="col-md-6 table-container">
            <table>
                <thead>
                    <tr>
                        <th colspan="2" class="text-center">Booking Details</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">Car Type</th>
                        <td><?php echo htmlspecialchars($carName); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Rental Duration</th>
                        <td><?php echo $duration . ' days'; ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Pick-up</th>
                        <td><?php echo $reservation['pickupDate'] . ', ' . $reservation['pickupTime'] . ' (' . htmlspecialchars($reservation['pickupLocation']) . ')'; ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Return</th>
                        <td><?php echo $reservation['returnDate'] . ', ' . $reservation['returnTime'] . ' (' . htmlspecialchars($reservation['returnLocation']) . ')'; ?></td>
                    </tr>
                </tbody>
            </table>

            <!-- Voucher Code Table -->
            <table>
                <thead>
                    <tr>
                        <th colspan="2" class="text-center">Voucher Code</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="2" class="text-center">
                            <div class="voucher-code-container">
                                <input type="text" class="form-control form-control-sm" placeholder="Enter Voucher Code" id="voucherCode" name="voucherCode">
                                <button class="btn btn-primary btn-sm" type="button" id="applyVoucherBtn">Apply</button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Payment Summary Table -->
        <div class="col-md-6 table-container">
            <table>
                <thead>
                    <tr>
                        <th colspan="2" class="text-center">Payment Summary</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">Price Per Day</th>
                        <td>₱<?php echo number_format($pricePerDay, 2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Rental Fee</th>
                        <td id="rentalFee">₱<?php echo number_format($rentalFee, 2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Total Price</th>
                        <td id="totalPrice">₱<?php echo number_format($rentalFee, 2); ?></td>
                    </tr>
                </tbody>
            </table>

        <!-- Payment Amount Table -->
        <table>
            <thead>
                <tr>
                    <th colspan="2" class="text-center">Enter Payment Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="number" id="paymentAmount" class="form-control" name="paymentAmount" placeholder="Enter amount" /></td>
                    <td><button class="btn btn-primary btn-sm" id="calculateChangeBtn" type="button">Calculate Change</button></td>
                </tr>
            </tbody>
        </table>

        <!-- Change Computation Table -->
        <table>
            <thead>
                <tr>
                    <th colspan="2" class="text-center">Change Computation</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">Amount Paid</th>
                    <td id="amountPaid">₱0</td>
                </tr>
                <tr>
                    <th scope="row">Change</th>
                    <td id="change">₱0</td>
                </tr>
            </tbody>
        </table>

        <!-- Hidden input to pass the amount paid to receipt page -->
        <input type="hidden" id="hiddenPaymentAmount" name="hiddenPaymentAmount" value="0" />
        <input type="hidden" id="hiddenChange" name="hiddenChange" value="<?php echo $change; ?>" />

        <!-- Action Buttons -->
        <div class="buttons">
            <a href="perdeets.html">
                <button type="button">Back</button>
            </a>
            <button type="submit" class="btn btn-primary">Confirm Booking</button>
        </div>
    </div>
</div>
</div>


    <!-- Footer -->
    <footer class="page-footer text-white py-4 text-center">
        <div>© 2024 Copyright: Carvo.com</div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- JavaScript for Handling Payment Amount and Change -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const header = document.querySelector('header'); // Select the header element directly

            // Scroll event listener for the sticky header
            window.addEventListener('scroll', function() {
                if (window.scrollY > 50) {
                    header.classList.add('sticky');
                } else {
                    header.classList.remove('sticky');
                }
            });
        });
        
        document.getElementById('calculateChangeBtn').addEventListener('click', function() {
        const rentalFee = parseFloat(document.getElementById('rentalFee').innerText.replace('₱', '').replace(',', ''));
        const paymentAmount = parseFloat(document.getElementById('paymentAmount').value);

        if (isNaN(paymentAmount) || paymentAmount < rentalFee) {
            alert('Please enter a valid payment amount greater than or equal to the rental fee.');
            return;
        }

        const change = paymentAmount - rentalFee;
        document.getElementById('amountPaid').innerText = '₱' + paymentAmount.toFixed(2);
        document.getElementById('change').innerText = '₱' + change.toFixed(2);

        // Set the hidden input value to the amount paid
        document.getElementById('hiddenPaymentAmount').value = paymentAmount.toFixed(2);
        document.getElementById('hiddenChange').value = change.toFixed(2);
    });

        document.getElementById('applyVoucherBtn').addEventListener('click', function() {
            const voucherCode = document.getElementById('voucherCode').value.trim();
            if (voucherCode === "DISCOUNT10") {
                const discount = 0.10;
                const rentalFee = parseFloat(document.getElementById('rentalFee').innerText.replace('₱', '').replace(',', ''));
                const discountedPrice = rentalFee - (rentalFee * discount);
                document.getElementById('rentalFee').innerText = '₱' + discountedPrice.toFixed(2);
                document.getElementById('totalPrice').innerText = '₱' + discountedPrice.toFixed(2);
                alert('Voucher applied successfully! 10% discount applied.');
            } else {
                alert('Invalid voucher code.');
            }
        });
    </script>
</body>
</html>
