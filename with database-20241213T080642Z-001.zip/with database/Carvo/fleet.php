<?php
// Database connection
$host = 'localhost';
$db = 'carvo';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'add') {
        $name = $_POST['name'];
        $category = $_POST['category'];
        $image = $_POST['image'];
        $pricePerDay = $_POST['price_per_day'];
        $rentalStatus = $_POST['rental_status'];
        $seats = $_POST['seats'];
        $luggage = $_POST['luggage'];
        $transmission = $_POST['transmission'];
        $fuelType = $_POST['fuel_type'];
        $specifications = $_POST['specifications'];

        $stmt = $conn->prepare("INSERT INTO cars (name, category, image, price_per_day, rental_status, seats, luggage, transmission, fuel_type, specifications) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdsissss", $name, $category, $image, $pricePerDay, $rentalStatus, $seats, $luggage, $transmission, $fuelType, $specifications);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'update') {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $category = $_POST['category'];
        $image = $_POST['image'];
        $pricePerDay = $_POST['price_per_day'];
        $rentalStatus = $_POST['rental_status'];
        $seats = $_POST['seats'];
        $luggage = $_POST['luggage'];
        $transmission = $_POST['transmission'];
        $fuelType = $_POST['fuel_type'];
        $specifications = $_POST['specifications'];

        $stmt = $conn->prepare("UPDATE cars SET name = ?, category = ?, image = ?, price_per_day = ?, rental_status = ?, seats = ?, luggage = ?, transmission = ?, fuel_type = ?, specifications = ? WHERE id = ?");
        $stmt->bind_param("sssdsissssi", $name, $category, $image, $pricePerDay, $rentalStatus, $seats, $luggage, $transmission, $fuelType, $specifications, $id);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'remove') {
        $id = $_POST['id'];
        $stmt = $conn->prepare("DELETE FROM cars WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }
}

// Fetch cars
$carsResult = $conn->query("SELECT * FROM cars");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fleet Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="fleetmanagement.css">
    <script>
        function populateFormFromButton(button) {
            document.getElementById('id').value = button.getAttribute('data-id');
            document.getElementById('name').value = button.getAttribute('data-name');
            document.getElementById('category').value = button.getAttribute('data-category');
            document.getElementById('image').value = button.getAttribute('data-image');
            document.getElementById('price_per_day').value = button.getAttribute('data-price');
            document.getElementById('rental_status').value = button.getAttribute('data-status');
            document.getElementById('seats').value = button.getAttribute('data-seats');
            document.getElementById('luggage').value = button.getAttribute('data-luggage');
            document.getElementById('transmission').value = button.getAttribute('data-transmission');
            document.getElementById('fuel_type').value = button.getAttribute('data-fuel');
            document.getElementById('specifications').value = button.getAttribute('data-specifications');
        }
    </script>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="logo.png" alt="Logo" height="50">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="dashboard.html">Dashboard</a>
                <a class="nav-item nav-link"  href="index.php">Manage Users</a>
                <a class="nav-item nav-link active" href="fleet.php">Manage Fleet</a>
            </div>
            <!-- Logout button -->
            <form method="POST" action="logout.php" class="ms-auto">
                <button type="submit" class="btn btn-danger">Logout</button>
            </form>
        </div>
    </div>
</nav>
<br>


<!-- Container for the Form -->
<div class="container mt-5">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h3>Fleet Management</h3>
        </div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="id" id="id">
                <div class="mb-3">
                    <label for="name" class="form-label">Car Name</label>
                    <input type="text" name="name" id="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="category" class="form-label">Category</label>
                    <input type="text" name="category" id="category" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Image URL</label>
                    <input type="text" name="image" id="image" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="price_per_day" class="form-label">Price Per Day</label>
                    <input type="number" name="price_per_day" id="price_per_day" class="form-control" step="0.01" required>
                </div>
                <div class="mb-3">
                    <label for="rental_status" class="form-label">Rental Status</label>
                    <select name="rental_status" id="rental_status" class="form-select" required>
                        <option value="Available">Available</option>
                        <option value="Rented">Rented</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="seats" class="form-label">Seats</label>
                    <input type="number" name="seats" id="seats" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="luggage" class="form-label">Luggage</label>
                    <input type="number" name="luggage" id="luggage" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="transmission" class="form-label">Transmission</label>
                    <select name="transmission" id="transmission" class="form-select" required>
                        <option value="M">Manual</option>
                        <option value="A">Automatic</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="fuel_type" class="form-label">Fuel Type</label>
                    <input type="text" name="fuel_type" id="fuel_type" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="specifications" class="form-label">Specifications</label>
                    <textarea name="specifications" id="specifications" class="form-control"></textarea>
                </div>
                <button type="submit" name="action" value="add" class="btn btn-primary">Add Car</button>
                <button type="submit" name="action" value="update" class="btn btn-warning">Update Car</button>
            </form>
        </div>
    </div>
</div>

<!-- Display the Table -->
<div class="container mt-5">
    <h2>Car Fleet</h2>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Image</th>
            <th>Price</th>
            <th>Status</th>
            <th>Seats</th>
            <th>Luggage</th>
            <th>Transmission</th>
            <th>Fuel</th>
            <th>Specifications</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($car = $carsResult->fetch_assoc()): ?>
            <tr>
                <td><?= $car['id']; ?></td>
                <td><?= $car['name']; ?></td>
                <td><?= $car['category']; ?></td>
                <td><img src="<?= $car['image']; ?>" alt="<?= $car['name']; ?>" width="100"></td>
                <td><?= $car['price_per_day']; ?></td>
                <td><?= $car['rental_status']; ?></td>
                <td><?= $car['seats']; ?></td>
                <td><?= $car['luggage']; ?></td>
                <td><?= $car['transmission']; ?></td>
                <td><?= $car['fuel_type']; ?></td>
                <td><?= $car['specifications']; ?></td>
                <td>
                    <button class="btn btn-info"
                            data-id="<?= $car['id']; ?>"
                            data-name="<?= htmlspecialchars($car['name'], ENT_QUOTES); ?>"
                            data-category="<?= htmlspecialchars($car['category'], ENT_QUOTES); ?>"
                            data-image="<?= htmlspecialchars($car['image'], ENT_QUOTES); ?>"
                            data-price="<?= $car['price_per_day']; ?>"
                            data-status="<?= $car['rental_status']; ?>"
                            data-seats="<?= $car['seats']; ?>"
                            data-luggage="<?= $car['luggage']; ?>"
                            data-transmission="<?= $car['transmission']; ?>"
                            data-fuel="<?= htmlspecialchars($car['fuel_type'], ENT_QUOTES); ?>"
                            data-specifications="<?= htmlspecialchars($car['specifications'], ENT_QUOTES); ?>"
                            onclick="populateFormFromButton(this)">
                        Edit
                    </button>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="id" value="<?= $car['id']; ?>">
                        <button type="submit" name="action" value="remove" class="btn btn-danger">Remove</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
