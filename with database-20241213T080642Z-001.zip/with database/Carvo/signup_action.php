<?php
// Start the session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carvo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form data is received
if (isset($_POST['name'], $_POST['email'], $_POST['uname'], $_POST['psw'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $username = $conn->real_escape_string($_POST['uname']);
    $password = $_POST['psw']; // Store password as plain text

    // Insert user data into the database
    $sql = "INSERT INTO users (name, email, username, password) VALUES ('$name', '$email', '$username', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Sign Up Successful!'); window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href='login.php';</script>";
    }
} else {
    echo "<script>alert('Please fill in all fields.'); window.location.href='login.php';</script>";
}

$conn->close();
?>
