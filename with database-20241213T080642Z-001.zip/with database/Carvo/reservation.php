<?php
// Connect to the database
require_once('db.php');

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $car_id = $_POST['car_id'];
    $pickup_date = $_POST['pickup_date'];
    $return_date = $_POST['return_date'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Insert booking details into the reservations table
    $query = "INSERT INTO reservations (car_id, pickup_date, return_date, name, email) 
              VALUES ('$car_id', '$pickup_date', '$return_date', '$name', '$email')";
    $result = mysqli_query($conn, $query);

    // Update car status to 'Rented'
    $updateQuery = "UPDATE cars SET rental_status = 'Rented' WHERE id = '$car_id'";
    mysqli_query($conn, $updateQuery);

    if ($result) {
        echo "Booking confirmed!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
