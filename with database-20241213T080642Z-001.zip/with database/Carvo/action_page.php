<?php
// Start the session
session_start();
include('functions.php');

// Check if the form data is received
if (isset($_POST['uname']) && isset($_POST['psw'])) {
    $username = $_POST['uname'];
    $password = $_POST['psw'];

    // Validate the credentials
    if ($username === 'admin' && $password === 'admin123') {
        // Redirect to admin.html
        header('Location: dashboard.html');
        exit();
    } else {
        // Redirect to index.html for any other username and password
        header('Location: index.html');
        exit();
    }
} else {
    // Redirect to the login form if no data is submitted
    header('Location: login.html');
    exit();
}

?>
