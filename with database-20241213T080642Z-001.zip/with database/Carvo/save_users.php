<?php
include('db.php'); // Database connection

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$name = $data['name'];
$email = $data['email'];
$username = $data['username'];
$password = $data['password'];

if ($id) {
    // Update existing customer
    $query = "UPDATE users SET name = :name, email = :email, username = :username, password = :password WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
} else {
    // Insert new customer
    $query = "INSERT INTO users (name, email, username, password) VALUES (:name, :email, :username, :password)";
    $stmt = $pdo->prepare($query);
}

$stmt->bindParam(':name', $name);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':username', $username);
$stmt->bindParam(':password', $password);
$stmt->execute();
?>
