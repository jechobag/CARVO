<?php
include 'db.php'; // Include the database connection

$sql = "SELECT id, name, price_per_day, category, seats, luggage, transmission, fuel_type, image, rental_status, specifications FROM cars";
$result = $conn->query($sql);

$cars = [];
while ($row = $result->fetch_assoc()) {
    $cars[] = $row;
}

echo json_encode($cars); // Return the data as JSON
?>
