<?php
session_start(); // Start the session to store reservation data

include 'db.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $carId = $_POST['carId'];
    $pickupDate = $_POST['pickupDate'];
    $pickupTime = $_POST['pickupTime'];
    $returnDate = $_POST['returnDate'];
    $returnTime = $_POST['returnTime'];
    $pickupLocation = $_POST['pickupLocation'];
    $returnLocation = $_POST['returnLocation'];
    $sameLocation = isset($_POST['sameLocation']) ? 1 : 0;
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // SQL to insert reservation
    $sql = "INSERT INTO reservations (car_id, pickup_date, pickup_time, return_date, return_time, pickup_location, return_location, same_location, name, email, phone)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("isssssssssi", $carId, $pickupDate, $pickupTime, $returnDate, $returnTime, $pickupLocation, $returnLocation, $sameLocation, $name, $email, $phone);

        if ($stmt->execute()) {
            // Get the inserted reservation ID
            $reservationId = $stmt->insert_id;

            // Store reservation details in the session to pass them to the next page
            $_SESSION['reservation'] = [
                'reservationId' => $reservationId,
                'carId' => $carId,
                'pickupDate' => $pickupDate,
                'pickupTime' => $pickupTime,
                'returnDate' => $returnDate,
                'returnTime' => $returnTime,
                'pickupLocation' => $pickupLocation,
                'returnLocation' => $returnLocation,
                'sameLocation' => $sameLocation,
                'name' => $name,
                'email' => $email,
                'phone' => $phone
            ];

            // Update the car status to 'rented' in the cars table
            $updateCarStatusSql = "UPDATE cars SET rental_status = 'rented' WHERE id = ?";
            if ($updateStmt = $conn->prepare($updateCarStatusSql)) {
                $updateStmt->bind_param("i", $carId);
                $updateStmt->execute();
                $updateStmt->close();
            } else {
                echo "Error updating car status: " . $conn->error;
            }

            // Redirect to the confirmation page (perdetails.php)
            header("Location: perdetails.php");
            exit(); // Make sure to stop further script execution after the redirect
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>
