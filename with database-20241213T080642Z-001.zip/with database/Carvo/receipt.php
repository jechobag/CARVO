<?php
session_start(); // Start the session to access reservation data
include('db.php'); // Include your database connection file

// Check if reservation details are in the session
if (isset($_SESSION['reservation'])) {
    $reservation = $_SESSION['reservation'];
    $carId = $reservation['carId'];

    // Fetch the car name and price from the 'cars' table based on carId
    $sql = "SELECT name, category, seats, luggage, transmission, fuel_type, price_per_day FROM cars WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $carId);
        $stmt->execute();
        $stmt->bind_result($carName, $category, $seats, $luggage, $transmission, $fuelType, $pricePerDay);
        $stmt->fetch();
        $stmt->close();
        
        // Check if the car was found
        if (!$carName || !$category || !$seats || !$luggage || !$transmission || !$fuelType) {
            $carName = 'Unknown Car'; // Default in case of an error
            $category = 'Unknown Category';
            $seats = 'Unknown';
            $luggage = 'Unknown';
            $transmission = 'Unknown';
            $fuelType = 'Unknown';
            $pricePerDay = 0; // Default price
        }
    } else {
        $carName = 'Unknown Car'; // Default in case of an error
        $category = 'Unknown Category';
        $seats = 'Unknown';
        $luggage = 'Unknown';
        $transmission = 'Unknown';
        $fuelType = 'Unknown';
        $pricePerDay = 0; // Default price
    }

    // Calculate rental duration (assuming pickup and return dates are in 'Y-m-d' format)
    $pickupDate = new DateTime($reservation['pickupDate']);
    $returnDate = new DateTime($reservation['returnDate']);
    $duration = $pickupDate->diff($returnDate)->days;

    // Ensure that the duration is at least 1 day
    if ($duration < 1) {
        $duration = 1; // Set to 1 day if it's less than 1
    }

    $rentalFee = $duration * $pricePerDay;

    // Customer details
    $name = htmlspecialchars($reservation['name']);
    $email = htmlspecialchars($reservation['email']);
    $phone = htmlspecialchars($reservation['phone']);
    $pickupLocation = htmlspecialchars($reservation['pickupLocation']);
    $returnLocation = htmlspecialchars($reservation['returnLocation']);
    $sameLocation = $reservation['sameLocation'] ? 'Yes' : 'No';
} else {
    // Redirect to the home page if no reservation found
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation Receipt</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <!-- Custom Styles -->

</head>
<style>
        /* Floating effect for the receipt container */
        .receipt-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px;
            background: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Floating shadow */
            border-radius: 10px; /* Rounded corners */
            transition: all 0.3s ease;
        }

        .receipt-container:hover {
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2); /* Slightly bigger shadow on hover */
        }

        /* Title and other header styles */
        h2 {
            margin-bottom: 30px;
        }

        h4 {
            margin-top: 20px;
        }

        /* Action Buttons Style */
        .btn-custom {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }

        .btn-custom:hover {
            background-color: #218838;
        }
    </style>
<body>
    <header class="p-3">
            <nav class="navbar navbar-expand-lg fixed-top fleet-navbar">
                <a class="navbar-brand" href="#">
                    <img src="logo.png" alt="Logo" height="30">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a href="index.html" class="nav-link">HOME</a></li>
                        <li class="nav-item"><a href="fleet.html" class="nav-link active" aria-current="page">FLEET</a></li>
                        <li class="nav-item"><a href="about-us.html" class="nav-link">ABOUT US</a></li>
                        <li class="nav-item"><a href="contact.html" class="nav-link">CONTACT US</a></li>
                    </ul>
                </div>
            </nav>
        </header>

        <div class="hero-section-fleet">
        <div class="overlay-fleet"></div>
        <div class="container text-center text-white">
            <h1>OUR FLEET</h1>
            <p>Find the perfect ride in our collection of clean, quality-assured vehicles.</p>
        </div>
    </div>

    <div class="container">
        <h2 class="text-center">Reservation Receipt</h2>
        <hr>

        <!-- Customer Information -->
        <h4>Customer Information</h4>
        <ul>
            <li><strong>Name:</strong> <?php echo $name; ?></li>
            <li><strong>Email:</strong> <?php echo $email; ?></li>
            <li><strong>Phone:</strong> <?php echo $phone; ?></li>
        </ul>

        <!-- Car Details -->
        <h4>Car Details</h4>
        <ul>
            <li><strong>Car:</strong> <?php echo $carName; ?></li>
            <li><strong>Category:</strong> <?php echo $category; ?></li>
            <li><strong>Seats:</strong> <?php echo $seats; ?></li>
            <li><strong>Luggage Capacity:</strong> <?php echo $luggage; ?> bags</li>
            <li><strong>Transmission:</strong> <?php echo $transmission; ?></li>
            <li><strong>Fuel Type:</strong> <?php echo $fuelType; ?></li>
        </ul>

        <!-- Reservation Details -->
        <h4>Reservation Details</h4>
        <ul>
            <li><strong>Pick-up Date/Time:</strong> <?php echo $pickupDate->format('F j, Y') . ' ' . $reservation['pickupTime']; ?></li>
            <li><strong>Return Date/Time:</strong> <?php echo $returnDate->format('F j, Y') . ' ' . $reservation['returnTime']; ?></li>
            <li><strong>Pick-up Location:</strong> <?php echo $pickupLocation; ?></li>
            <li><strong>Return Location:</strong> <?php echo $returnLocation; ?></li>
            <li><strong>Same location for return?</strong> <?php echo $sameLocation; ?></li>
        </ul>

        <!-- Payment Details -->
        <h4>Payment Details</h4>
        <ul>
            <li><strong>Price per Day:</strong> ₱<?php echo number_format($pricePerDay, 2); ?></li>
            <li><strong>Rental Duration:</strong> <?php echo $duration; ?> day(s)</li>
            <li><strong>Total Rental Fee:</strong> ₱<?php echo number_format($rentalFee, 2); ?></li>
            <!-- Added Amount Paid Section -->
            <li><strong>Amount Paid:</strong> ₱<?php echo isset($_POST['hiddenPaymentAmount']) ? number_format($_POST['hiddenPaymentAmount'], 2) : '₱0.00'; ?></li>
            <!-- Added Change Section -->
            <li><strong>Change:</strong> ₱<?php echo isset($_POST['hiddenChange']) ? number_format($_POST['hiddenChange'], 2) : '₱0.00'; ?></li>
        </ul>

        <!-- Action Buttons -->
        <div class="text-center">
            <a href="index.html" class="btn-custom">Back to Homepage</a>
            <a href="fleet.html" class="btn-custom">Confirm Reservation</a>
        </div>



    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const header = document.querySelector('header'); // Select the header element directly

            // Scroll event listener for the sticky header
            window.addEventListener('scroll', function() {
                if (window.scrollY > 50) {
                    header.classList.add('sticky');
                } else {
                    header.classList.remove('sticky');
                }
            });
        });
        </script>
</body>
</html>
