<?php
include('functions.php');

// Handle Add, Edit, and Delete requests
if (isset($_POST['action'])) {
    if ($_POST['action'] == 'add') {
        // Add a new user
        addUser($_POST['name'], $_POST['email'], $_POST['username'], $_POST['password'], $_POST['role']);
    } elseif ($_POST['action'] == 'edit') {
        // Edit an existing user
        updateUser($_POST['id'], $_POST['name'], $_POST['email'], $_POST['username'], $_POST['password'], $_POST['role']);
    }
} elseif (isset($_GET['delete'])) {
    // Delete a user
    deleteUser($_GET['delete']);
}

// Fetch all users for display
$users = getAllUsers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    
</head>
<style>
body {
            font-family: 'Open Sans', sans-serif;
            background-image: url('loginbg.jpg');
            background-size: cover; /* Ensures the image covers the entire background */
            background-position: center; /* Centers the image */
            background-repeat: no-repeat; /* Prevents the image from repeating */
            background-attachment: fixed; /* Keeps the background fixed when scrolling */
        }

        /* Card Holder Styling */
        .card-holder {
            background-color: #fff; /* White background for the card */
            padding: 10px;
            margin: 20px auto;
            max-width: 600px; /* Restrict max width of the card */
            width: 90%; /* Make the card responsive */
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        /* Header Styling */
        h1 {
            text-align: center;
            color: #333;
            padding: 20px 0;
        }

        h2 {
            text-align: center;
            color: #333;
            padding-top: 10px;
        }

        /* Form Styling */
        form {
            background-color: transparent; /* Ensure no extra background for the form */
            padding: 20px;
            margin: 0;
        }

        label {
            font-size: 14px;
            color: #444;
            margin-bottom: 5px;
            display: block;
        }

        /* Input and Select Fields */
        input[type="text"], input[type="email"], input[type="password"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        /* Input Focus Styling */
        input[type="text"]:focus, input[type="email"]:focus, input[type="password"]:focus, select:focus {
            border-color: #4CAF50;
            outline: none;
        }

        /* Button Styling */
        button {
            width: 48%;
            padding: 10px;
            font-size: 14px;
            text-align: center;
            font-weight: bold;
            border-radius: 5px;
            border: none;
            margin-top: 10px;
            cursor: pointer;
        }

        button[type="submit"] {
            background-color: #28a745;
            color: white;
        }

        button[type="submit"]:hover {
            opacity: 0.8;
        }

        /* Add New User Button */
        button#clearForm {
            background-color: #f0ad4e;
            color: white;
            margin-top: 10px;
        }

        button#clearForm:hover {
            opacity: 0.8;
        }

        /* Table Styling */
        table {
            width: 80%; /* Restrict table width */
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white; /* Ensure table has solid background */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .navbar {
    width: 100%;
    background-color: #343a40;
    padding: 0.25rem 0.5rem; /* Reduced padding to make navbar more compact */
    height: 75px; /* Explicit height to control overall size */
}

.navbar-nav .nav-item .nav-link {
    font-weight: 600;
    color: white;
    font-size: 14px; /* Smaller font size for links */
    padding: 0.25rem 0.5rem; /* Reduced padding on links */
}

.navbar-nav {
    flex-grow: 1;
    display: flex;
    justify-content: flex-start; /* Align items to the left */
}

.navbar-brand img {
    height: 50px; /* Reduced logo size */
}
        
/* Custom Button Styling for Logout */
.logout-btn {
    background-color: #dc3545 !important;  /* Red background */
    color: white !important;
    border: none;
    padding: 10px 20px; /* Ensure padding for button */
    border-radius: 5px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
    display: block;  /* Ensure full width */
    width: 100%; /* Ensure it stretches to the container's width */
}

.logout-btn:hover {
    background-color: #c82333 !important;  /* Darker red on hover */
    opacity: 0.8;
}

.logout-btn:active {
    background-color: #bd2130 !important;  /* Even darker red when active */
}

/* Ensure proper spacing and alignment */
.navbar-nav {
    flex-grow: 1;
    display: flex;
    justify-content: flex-start; /* Align items to the left */
}

.d-flex {
    display: flex;
}

.ms-auto {
    margin-left: auto;
}


        /* Responsive Design for Mobile */
        @media screen and (max-width: 768px) {
            .card-holder {
                width: 90%; /* Ensure card holder is responsive */
                padding: 15px;
            }

            button {
                width: 100%;
                margin: 10px 0;
            }

            table {
                width: 100%;
            }
        }



    
</style>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="logo.png" alt="Logo" height="50">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-item nav-link" href="dashboard.html">Dashboard</a>
                    <a class="nav-item nav-link active" href="index.php">Manage Users</a>
                    <a class="nav-item nav-link" href="fleet.php">Manage Fleet</a>
                </div>
                <!-- Logout button aligned to the right -->
                <form method="POST" action="logout.php" class=" ms-auto">
                    <button type="submit" class="logout-btn">Logout</button>
                </form>
            </div>
        </div>
    </nav>

  

    <div class="card-holder">
        <h1>User Management System</h1>
    </div>


<div class="card-holder">
    <!-- Add/Edit User Form -->
    <h2>Add or Edit User</h2>
    <form action="index.php" method="POST">
        <input type="hidden" name="id" id="userId">
        
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>
        
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>
        
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>
        
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        
        <label for="role">Role:</label>
        <select name="role" id="role" required>
            <option value="user">User</option>
            <option value="admin">Admin</option>
        </select>
        
        <!-- Buttons -->
        <button type="submit" name="action" value="add">Add User</button>
        <button type="submit" name="action" value="edit">Save Changes</button>
    </form>
</div>


    <!-- User List -->
    <div class = "container">
    <div class="card mt-4">
    <div class="card-header">
        <h2>All Users</h2>
    </div>
    <div class="card-body">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Username</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo $user['name']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td><?php echo $user['username']; ?></td>
                    <td><?php echo $user['role']; ?></td>
                    <td>
                        <!-- Edit Button -->
                        <a href="javascript:void(0);" 
                           onclick="editUser(<?php echo $user['id']; ?>, '<?php echo $user['name']; ?>', '<?php echo $user['email']; ?>', '<?php echo $user['username']; ?>', '<?php echo $user['role']; ?>')">Edit</a>

                        <!-- Delete Button -->
                        <a href="index.php?delete=<?php echo $user['id']; ?>" 
                           onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
            </div>
            </div>

    <!-- JavaScript for Add and Edit Operations -->
    <script>
        // Pre-fill the form for editing a user
        function editUser(id, name, email, username, role) {
            document.getElementById('userId').value = id;
            document.getElementById('name').value = name;
            document.getElementById('email').value = email;
            document.getElementById('username').value = username;
            document.getElementById('role').value = role;

            // Change buttons for editing
            document.querySelector("button[value='edit']").style.display = "inline";
            document.querySelector("button[value='add']").style.display = "none";
        }

        // Clear form for adding a new user
        function clearForm() {
            document.getElementById('userId').value = '';
            document.getElementById('name').value = '';
            document.getElementById('email').value = '';
            document.getElementById('username').value = '';
            document.getElementById('password').value = '';
            document.getElementById('role').value = 'user';

            // Change buttons for adding
            document.querySelector("button[value='edit']").style.display = "none";
            document.querySelector("button[value='add']").style.display = "inline";
        }
    </script>

    
</body>
</html>
