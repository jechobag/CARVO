-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2024 at 04:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carvo`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price_per_day` decimal(10,2) DEFAULT NULL,
  `rental_status` enum('Available','Rented') DEFAULT 'Available',
  `seats` int(11) NOT NULL,
  `luggage` int(11) NOT NULL,
  `transmission` enum('M','A') NOT NULL,
  `fuel_type` varchar(20) NOT NULL,
  `specifications` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `name`, `category`, `image`, `price_per_day`, `rental_status`, `seats`, `luggage`, `transmission`, `fuel_type`, `specifications`) VALUES
(1, 'Hatchback', 'Economy', 'hatchback.jpg', 1500.00, 'Rented', 5, 1, 'A', 'Gasoline', 'Electric windows, USB port, Electric door lock, Audio System, Driver\'s Airbag'),
(2, 'Sedan', 'Standard', 'sedan.jpg', 1750.00, 'Rented', 5, 3, 'M', 'Gasoline', 'Electric windows, USB port, Electric door lock, Passenger Air Bag, Audio System, Driver\'s Airbag'),
(3, 'Premium Sedan', 'Premium', 'premsedan.jpg', 2000.00, 'Rented', 5, 3, 'A', 'Gasoline', 'Electric windows, USB port, Electric door lock, Crash Sensor, Passenger Air Bag, Audio System, Driver\'s Airbag'),
(4, 'Medium AUV', 'AUV', 'MedAUV.jpg', 2650.00, 'Available', 7, 3, 'A', 'Gasoline', 'Electric windows, USB port, Electric door lock, Passenger Air Bag, Audio System, Driver\'s Airbag'),
(5, 'Van', 'Utility', 'van.jpg', 4100.00, 'Available', 13, 4, 'M', 'Diesel', 'Electric windows, USB port, Electric door lock, Passenger Air Bag, Audio System, Driver\'s Airbag, Rear A/C'),
(6, 'SUV', 'Luxury', 'SUV.jpg', 3550.00, 'Available', 7, 3, 'A', 'Diesel', 'ABS, Bluetooth, Electric windows, USB port, Electric door lock, CD player, Audio System, Driver\'s Airbag'),
(7, 'Pickup Truck', 'Utility', 'pickups.png', 1950.00, 'Available', 5, 8, 'A', 'Gasoline', 'Electric windows, USB port, Electric door lock, Audio System, Driver\'s Airbag, Passenger Air Bag');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `car_id` int(11) DEFAULT NULL,
  `pickup_date` date NOT NULL,
  `pickup_time` time NOT NULL,
  `return_date` date NOT NULL,
  `return_time` time NOT NULL,
  `pickup_location` varchar(255) NOT NULL,
  `return_location` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `same_location` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `car_id`, `pickup_date`, `pickup_time`, `return_date`, `return_time`, `pickup_location`, `return_location`, `name`, `email`, `phone`, `same_location`) VALUES
(10, 1, '2024-11-30', '11:01:00', '2024-12-07', '11:01:00', 'TIP Cubao', 'TIP Cubao', 'Karl Porcal', 'ktsurugi420@gmail.com', '9604760785', 0),
(11, 2, '2024-11-30', '11:04:00', '2024-12-07', '11:04:00', 'TIP Cubao', 'TIP Cubao', 'Karl Porcal', 'ktsurugi420@gmail.com', '9604760785', 0),
(12, 3, '2024-11-30', '11:22:00', '2024-12-07', '11:22:00', 'TIP Cubao', 'TIP Cubao', 'Karl Porcal', 'ktsurugi420@gmail.com', '9604760785', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `role`, `created_at`) VALUES
(12, 'Karl Porca', 'ktsurugi420@gmail.com', 'callyfour', '123', 'user', '2024-11-29 22:45:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `car_id` (`car_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
